#!/usr/bin/env bash

xelatex main
bibtex main
xelatex main
xelatex main
